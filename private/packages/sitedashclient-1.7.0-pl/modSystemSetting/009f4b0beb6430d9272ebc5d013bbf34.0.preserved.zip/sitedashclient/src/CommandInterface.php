<?php
namespace modmore\SiteDashClient;

interface CommandInterface
{
    public function run();
}