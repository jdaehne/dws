<?php
namespace modmore\SiteDashClient;

interface LoadDataInterface
{
    public function run();
}