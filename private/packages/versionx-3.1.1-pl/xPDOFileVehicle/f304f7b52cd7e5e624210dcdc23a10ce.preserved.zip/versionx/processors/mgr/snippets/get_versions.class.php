<?php
require_once dirname(__DIR__) . '/get_versions.class.php';

class VersionXSnippetsGetVersionsProcessor extends VersionXGetVersionsProcessor {
    public $classKey = 'vxSnippet';
}
return 'VersionXSnippetsGetVersionsProcessor';
