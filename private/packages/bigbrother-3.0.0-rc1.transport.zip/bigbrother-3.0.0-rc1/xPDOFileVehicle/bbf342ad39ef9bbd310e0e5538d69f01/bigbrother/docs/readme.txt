Big Brother
-----------

A collection of MODX Dashboard Widgets for Google Analytics v4.

Supports MODX 2.8+ and 3.0.0-alpha3+.

INSTALL INSTRUCTIONS:

- Install the package
- Add one (or more) of the Big Brother widgets to your dashboard via System > Dashboards on MODX2, or the Add button on the top right of the dashboard on MODX3.
- Navigate to the dashboard, and follow the provided information to authorize with your Google account.

NOTES & CREDITS:

- Developed by modmore
- Original 1.x development by @lossendae

BUGS AND DEVELOPMENT

To request improvements or report bugs, please visit GitHub: https://github.com/modmore/BigBrother

To support our open source work, please consider a donation via: https://modmore.com/extras/bigbrother/donate/
