<?php
/**
 * Permissions English Lexicon Entries for BigBrother
 *
 * @package bigbrother
 * @subpackage lexicon
 *
 */
$_lang['bigbrother.permission.authorize'] = 'Allows loading the BigBrother authorization manager page.';