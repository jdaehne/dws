<?php
require_once dirname(__DIR__) . '/get_versions.class.php';

class VersionXTemplatesGetVersionsProcessor extends VersionXGetVersionsProcessor {
    public $classKey = 'vxTemplate';
}
return 'VersionXTemplatesGetVersionsProcessor';
