Changelog for Tower

Tower 1.0.1
---------------------------------
+ Move get data to processor (endpoint changed)

Tower 1.0.0
---------------------------------
+ Initial Version

