-----------------------------------
Package: CrossContextsSettings
----------------------------------
Author: goldsky <goldsky@virtudraft.com>
        http://twitter.com/_goldsky

This is a custom plugin to manage cross contexts' settings