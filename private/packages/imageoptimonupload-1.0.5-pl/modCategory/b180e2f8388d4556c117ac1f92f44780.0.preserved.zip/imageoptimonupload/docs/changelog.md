Changelog for imageoptimonupload

imageoptimonupload 1.0.4
---------------------------------
+ Fix upload to non default media-sources


imageoptimonupload 1.0.3
---------------------------------
+ Add modmore extras support (Redactor, moreGallery, ContentBloks ...)
+ Restructuring code


imageoptimonupload 1.0.2
---------------------------------
+ Fix Plugin event handling for MODX 2.7.x


imageoptimonupload 1.0.1
---------------------------------
+ add usage for local and/or protectet server


imageoptimonupload 1.0.0
---------------------------------
Initial Version