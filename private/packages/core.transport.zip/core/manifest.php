<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '616f71bea16c0eaaab0050f0e4cf60d2',
      'native_key' => 'core',
      'filename' => 'modNamespace/145860bbb19ae113ce4d1d503a860747.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'f19d3eb0d736cc336a02b9633c5d4d74',
      'native_key' => 1,
      'filename' => 'modWorkspace/a399e119b7266c9505d610170972e2cd.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'b39fc26130d9652e727358e15712b595',
      'native_key' => 1,
      'filename' => 'modTransportProvider/69ce4f8037132c50b3aac8f8f792b9a6.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6ab6dd36d010907bccc273f80a7a0407',
      'native_key' => 'topnav',
      'filename' => 'modMenu/1455ea0b212484083ab325bff9e8812e.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '59bfb4015dded712a360df27210611f8',
      'native_key' => 'usernav',
      'filename' => 'modMenu/59e3fad49fcdccc1e020922a9b258f1f.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '18419008a0a26c95c1f3633b430e2bbc',
      'native_key' => 1,
      'filename' => 'modContentType/d57e40598ee914ab61dfd315edb42ad8.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '1276e52749e882c4b39d021468a76890',
      'native_key' => 2,
      'filename' => 'modContentType/65d67556da31023ad251214020ae39fe.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'be9fdcbbff4f3b11a87ecaa148e64676',
      'native_key' => 3,
      'filename' => 'modContentType/27431520336d57d7dca5110dca64ad96.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '8d53ed02bcdf5b35df885c02736fefa1',
      'native_key' => 4,
      'filename' => 'modContentType/b6e2382235ca89585ad3e53f61cd2841.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '3ca74739e0456a7011279fc96006970c',
      'native_key' => 5,
      'filename' => 'modContentType/bb1632dd22c4e5a58e69da5878f236db.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'f931cefeccb1e39ffd4231e440ad835a',
      'native_key' => 6,
      'filename' => 'modContentType/35477d883379c8405d3c6a984873a79c.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '912c3b364da6038e040ce8bcf9c40caa',
      'native_key' => 7,
      'filename' => 'modContentType/6c7c7eb31f7bf0ce52aaf96202eae568.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '008c61188e7d040d0601e834e4f9b8dd',
      'native_key' => 8,
      'filename' => 'modContentType/eb12d4b8167ba9a2382ef419ea7a5ab2.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '65c30094b08dec642a67253027c58053',
      'native_key' => NULL,
      'filename' => 'modClassMap/fce77a37a6333b9b841ce513a1efddc9.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c49185149841ccb4afd196aaf3bd16fc',
      'native_key' => NULL,
      'filename' => 'modClassMap/4e03484de3df6a349f4ab8ad48235fca.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '73b8f411baaccdf7354fb4cd09fbedd5',
      'native_key' => NULL,
      'filename' => 'modClassMap/6a3d50175b0735420fc1a9a2d9cbeabb.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '70a9516b2df91e3d9d5e9818bf7d94b0',
      'native_key' => NULL,
      'filename' => 'modClassMap/ace67f95dbcd5632654e750249fd6bad.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e4143c2ee051dbef19e51f915946d679',
      'native_key' => NULL,
      'filename' => 'modClassMap/c8bd7550be42385ecb0910cb89863a20.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '4d3d1c780453e5792070ca9007a05974',
      'native_key' => NULL,
      'filename' => 'modClassMap/76e73c7093592c9095c804b099f710a6.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e0ca16bb926d1f3e2b4dbf334ef8ea64',
      'native_key' => NULL,
      'filename' => 'modClassMap/8612311ffbb8f6f7075e984d1f9cc0fd.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '4008a4563243ca1def70ccc940a9214a',
      'native_key' => NULL,
      'filename' => 'modClassMap/1bd8525912e6f8fc690b70f456a38e7a.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'ba4501a3a359bc1abbcee5ec8b6821f1',
      'native_key' => NULL,
      'filename' => 'modClassMap/9b4e461ee42bfd80c20d9b5e9c751c3f.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3203c232d18afb0209ee7d334da2a8b7',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/557ea6bccac1346e460cab936a4cf86f.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '00c8548277cab9eb069338ecf85004c2',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/f137da36ed15d914ad63f5be4bf57b16.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '507027d5802e42cdbde76ff5035f8e3d',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/85192bd31d25277b856a0279ecba73c3.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '089bc756bc3a15fefb4265e3cf9b4727',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/952960ecd0e3a1a77aeb32d9110016a3.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55d27a11eccdb520fc42fa49f2260f3f',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/95941713b2199cc3c1de7ec369c0817a.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '700847144a97eb84af251eaf0b873206',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/76af81832bbaebd454dca223ed4834c8.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7258333592a2a3b4b956f04e05813722',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/d56176f9c05170291f6f44c9773dd48f.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19ea750a384fc9a3d45c598449f7595f',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/64c8549d5f0ebb01de136c64dcc95200.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33e74baffe1c8bc3656afebb5b096084',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/de824e53627703af6303ea5d4de572af.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96746bdbb62c28ecf6ab545eea06c205',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/5849784397cda3b47f497099f35f6002.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53161900b8e69374a8b7652b335cb5d1',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/b82c8ed7ff8c95551edfe97abdbadacd.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd9df3655953a77c838f184cdea897bd',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/ae0979f7f71b13fe207b1a7995beed09.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a863edae2c7edb1e79dc48fc63a6409',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/92061b7d16d257aabe0c29191f879f9b.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7605b9d501695fa03d23e7be0659dc4c',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/e6584b7d32b6440a3daccbf4e81454e7.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b4b04617ec70854ed0fdd29f3036547',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/48a5c566bc5c336fc6ec068f381358ff.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '361b81ee40ddd86cf874619986e5c2ea',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/1857da467d75c587ed38e661a21c9983.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e930caeac51bcab765bbe0a7fccabfcd',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/c76330783b1459a6e2b1e75c3cf3dbf2.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '72ad9016c810d4fd84b4c3c7066d0de2',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/fbd7b268f43f3d8318bfb18f440bf9f7.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '810f5f94766a00afa1c8848cb22928ab',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/7f580ffb0ed02dafe3cee98a70f92fc2.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e6d818246af1dfb62eade11fdb93888',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/a317fc18d06ef229bb29b7e1e6d6527b.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23209d7c627dbc79671b49b1cdc8cdb2',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/ce7c69c079eb9141b62666ce41cc44ca.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b3637f756c4c981ecef7800816375264',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/2b8dd3bbc95a943c333dad572d63e168.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55724239ad3efcb089de3121b9d9e2db',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/c9fe36998ce76f6c06274d7415fd6ab0.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2039a1aa36c53823bd0dce87c82d86b',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/669d3080647382765f1f93da0f0dd873.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '92f6e87eceb5648ee3ea313108292aa0',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/6375b9841153625069aa1463f58dd667.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d473be5aca312e35ee8932d07da3c88',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/ad82af265bad5895bce0788ecfdaab06.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a41141206bc8df130ddc53db662657f',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/d535da035d03ddb8a2b7badb06435ac0.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5db674bf6310c6188e45b651a133ffcb',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/b0e7762976bc14d6257619029b6dac0b.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4dae80c5161f4bede2b604d3f5cfcadf',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/0136f2b5bbc5e004dc43e758bd9a74d2.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41418626eebd5b175ca90047720dce1d',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/0990f117980215bfa2a66a4b80f2a63f.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b6a98facd79ce179d89df13c91c6997',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/1ce6caf698979e969a168cef06f31b1f.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6bcade77aa2d3e5d894c534cd711cdb2',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/580133ee6e7600d2cc13013dee0b40c4.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f69887252c3483c0c98e0f43c55d269b',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/87d5a0a108ba1d12c4102075bc8ddaf2.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad70d86c7c374b096ae21606bf1d4ffd',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/65c8d374404a9674de139eb88761b83e.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95fef42d1417a70ee8fc2d61ba78fad3',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/b64ed6076f4491493b5876c8b0625c57.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c5055f092c68f1a152cc871253fe677',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/f9036ee86370b704b9ddfbe4aa2b4bb4.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '948e25708925f52e8811cf11c50ca6b1',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/454bcfb06a3681855171cc33e4081a9a.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e43665b698ecd7de12a68860597e5d72',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/fdac7e2bc04d7287abed4e9546100fd3.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '52169a7681ec877a7e646bf51367c227',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/77a0f4113aa3ae298dc961a03523a99a.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f394430b38b5aeb0cd06bb18077eade',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/0131d1ca93ad6329441eae3bd6d9eebf.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ebb6f5357eb7b64d8415017a52f839d',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/97f721980a559ff1e4905894ca64510d.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3059f58b0630e3fdd4bddda9df9f889b',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/6bf60647be0900118daa051ba7630587.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32c0a946ad448be4bd203671a4a15053',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/2bc26094b523cc61f413b57165f62af2.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de7301a9b573475c3cf8d07deb1fcff5',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/2aeb4b9a39d77cc0ac2e01c5934ae0b8.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65b3e2e8ce7c70a4370dc0c6886b0108',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/e5fd0e755d6a49e2bd69104e06b7f35a.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d702ae51a9a55a150f3a6f81d5ed96b',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/2d549e418548c6df3dff275a2098861e.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd269cf537a5a84a2d2482dbbd6514091',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/4de9e51151a8d22b3af853011fd8f223.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5545bc45bf428a00ed4ce5b6f8b54ed5',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/393631ce278a6938e916f172da3ed9fe.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5764c42ee1f103e034714f1bca97560',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/0a38da1ff4fa1be81d28b8aad7733b53.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7ae7b170dbb55c7e73d379d0ad8d9d4',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/104d54e9ac28633fcccd6b3bbab9c774.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0bcceb8cacdf665fc5c012efe0a631c',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/4d2bf819e88ceb38add67911483a9602.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb3c4986e10623d58e02d8764e57352b',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/29e8e2caba40870d6fb870a9a20306b0.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5769b3fba261537aaf4aeaa80a2ce496',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/480f934c991f0c488d45506efa3dec34.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78343831e7acc96aa2bcd424a95d2741',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/8427b384c0874663c28bed15b9fd50b3.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fbbbbebb14d218f3027c4c53060aafea',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/b470b6f96791dd99a4c499f1dc54639c.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'caad7bce41ef02b1277d112ff0b33b8a',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/0b3c04a0c2edda6096a075220f18269c.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f6e1045832bc7c0b47fb2565f946b2f0',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/eea0c79c61720d994969f9ad5e92bde8.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d562062bfec5145af5fbe4766739dba',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/60e17e5a1f85e8420d1d587fd66829da.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02b5ba9aa3f460e3d53930edadc336c1',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/52b0569d9ed2e0f24f9f940fc6a515a0.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19e81d746613f20e3c4067a44f8186ba',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/aa8c674dde4e48f1bc8746f194ed1464.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '304502fb926d400f9721c28688bbb750',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/b9c16fb17ec038513813666196755473.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'baf48e259d3ad7574aef60b022e93920',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/468e04a2ea317bf4798dbc83b9947ab0.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99259992b3c6568116c613c67430f66b',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/f29222e5f2d65ee1eaf0d08700672e3e.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '315bdf393bb93345dc6f31bb8c1f6ae1',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/cbcbf103ac036887f62ec15cc9c0924c.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80061896cf4ded3472717e44bc9db096',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/6be60f01ddcae9f26789d35528242762.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cac66ecb84b0670c4ab3fcdc70020fb8',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/4689c9892c4aff6c882dcd4f2661a2cb.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '085b54433d889b48c3ebd77ba0d519e9',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/178f79c145220334f44cba32a8721b21.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eebb71481c08b5a396983ba4410a9c3d',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/9d82a90a1f9726f07726e9bad6da15cb.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2000d47e6aea6b8f03ec6416429cf5f4',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/970ff5a9fd1530e7f71d46e2b1069ea4.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a3d831d4a4fae4c25257e35df57148f',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/214802f806fbb049eab11db0628de37b.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be76ad67cd895987cf87238b093c9532',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/4428cd4db61caaece1658773089e3180.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2909301e2627edbb69edc4d66ccba3bd',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/8cefc1b0ad831f8e859eefe810aec18a.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d19c7def8928336022a6cd5ae41b01d',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/fb0dba03a40b968ae6d5a2ecc8ffc3d3.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7291ef45d35247f71f775058c945a443',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/c176c33601b6a4701e9d5e3271bbc083.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1be13668440d188983ca74c337af695',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/ebe2932cc5e4e3326673a32706050c08.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0ee2aa6dd290b87fbdb549c63b50419',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/b0dcc9c5bb8a300aab16b6c53d563039.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a21c8c61043e6988cbeb18464b58a506',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/ac355c6c392f553f539421e32cd67567.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '734c168710e6b8f5c69657ab6430e3a0',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/00df9cae366c611487258469924c46fe.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'adfd274b2faff8facf70aef6af7c7f1c',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/c48cba8306d0366976cf516bb6f9283e.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f3dd6a454c07bbbfc5c26ac8d8bb639a',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/f69c9d5dbc3452591557082ee5fb4be4.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e312e3f11ea4460f4e889b2a16daaa5e',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/d867b76537a3f2fd3946e28fb3d300bd.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f8ef6042ca23ba26c346153e033c945',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/d14f82c37a4513addbbdc94c0ba528b4.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1499d7104855bbb5814944505561d11',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/b34987c9a996427bf3efdc8560346788.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28837ab93037d223a1d8a8aab419d736',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/938d86fa21de3af43b9679afd35857f9.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5207169e1e6cebeb1fac673e6d851d03',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/176e90067d8803246bbba28ee56f81db.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64e051b9b86f82f4332be13cf9cd57ac',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/99113fe0d2f927c78f4df77cc7b0b224.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a89cca979bf6dc13aecf557f230ea3ca',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/92b24bc10d67a4498e44b4e1ad8c9254.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '689ed4f6ebba7d6f98498317f2f1500f',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/68b799680e337b4c76896a30804a2111.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '86179b0735e6261a85527b6ac1184751',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/d1342d7149592bf13c4f3493ecb13b30.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e26ce0282557fccdbb02f65d4cb6f440',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/6c263c875551bc93605a717d32211e3d.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1fa9ab96aad833c100d56a2d03ef9cfd',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/26e3ed7e0156668d0a2a55a9e945c5c3.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dcff5a3c55e6991f4021528d642a5b56',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/a0aa52035b5599c2b645af95295f8342.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8c636b0afd0a75f6ba93491dd2a8d9f',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/aff17681831ca76d0c3054fc08103150.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0fecbee827d7d2ec3033184036a853dd',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/7b41ffa5b43fc4ae6d3a024fbf45925c.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5afdb9b2e82c8183b0eebf0ecd4cf828',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/f27afd042b20f73caa7f31f407aaaa11.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4bc2cc856ccc759a0c446c702e51d93b',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/a22b21bef00081915e59b83b800b135b.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3cda08dc37d403caf4b4e86d17ec120e',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/8ff8df2618193738717571a019a1d5ff.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f89df4305acfeacbd651746d0dc6f3f4',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/facc4ade2dcd9edfe865411342bb3452.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75c602ad8005fb52e5b730b3cf89e839',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/bc6b46f5069433e6f45445e18c080810.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9be96774205651950050959748081110',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/25b899f34f6b278d514722fb25c88786.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6882c94691c38cb5f81899dceedd2242',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/05080115b9f1a44ee216cbc62dd3290a.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '185790a4205210ce4f53c1c52e0bb2a4',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/90e540bd840f3eade2bdc656d323e7fd.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '354a70a761ef598f6f0fab3be4349c08',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/b057840f6360d7543f9ecc88084ea939.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11d2bdbd91a93dcdab725a34994a6625',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/828d5317f4e4a9a2a4c2e82fec285dee.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3bbe04f11ae1b90c11622161954b3d97',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/1527bd71478189c2aa65ca0667237b97.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '897f0a0b5d05ab1f2f649edd960a009d',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/85af200aa9f0fae0d16560d191e0d093.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '875d2318953f43fb4395c11d64ffb99b',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/0ca4ad8613e1c44e8f9ff2d63b82da05.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '30ae00e3b1bcb900c9d6e74b830e9b9a',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/33758afc686086f94a22a389257a730d.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8346f48f3c366f0385b45307f7b9c833',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/79e11ebd4acc7701443108ef3a4d55de.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e43fd096e1851d3f3773e3f7a066013',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/069b22dd2e1d62edeb77e9ad7a202016.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '24d541c4041df019912e6ff53f833eb2',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/3e6658963168e0cd8e933206e81b18b7.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1ebb0a5d909007c1852cb7c3d6046b5',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/a73c7a39d930c83d34e061ca99fbf651.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '92049c23c1ff0ef6d2bf8cdfa5d7b3d6',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/0a562e40d52c9e78a7f93ced6a899c8f.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3418b8052f339aeeb185d6230d41688',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/e6bc94e58eae9cc6984d57588e5aa9f9.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ea37db5a604f8c05563c78d78a4cdaa',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'modEvent/2398530adb3d902c2a092db31c53387e.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ee8005d6750867c4a1f0aa0ff51ed3f',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/6b152d9d94f9612098ba167a09e47bb0.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '61f90402821547006ed45ad4f62d0964',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/53c9eb52d7ae63c53a009e5e65ddddfa.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fba63c8784d615b62f045de5da5718b7',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/77d63aa539041eb539e1d3c92258c427.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3dd10084e81fe883bd564347068765c2',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/b46efd337fe1f68d4adc33965a9de4de.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c321d7e86870ad7bf10889072fbf771c',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/802e38bd024ff3336b66529194054278.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6a3af322458795b50e0d2f4470c4963',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/ec1c72004df669dcf0b458e182cc7e18.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8fbc2ba37d0c86b0d121872b0d72845f',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/497b179df52791078be69ea8b257b497.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36a8c5a7eee35b588433e0ddbaf2b886',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/15c488013deac584e5c61b1cc60d123c.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a3fb0de819b22ef9d919e9276c1a2c13',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/ed6207aabd89d54c83d8064932225062.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c74f84343d5fc40671bb7157393dd1e4',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/8b73bce645174f596491bd5eb454b347.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d52fb1df3fdb6db040fede5b86a650d',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/986769229afd7f64c0c9dcb1d705ac92.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40c64a758d31927d8db85471427362bd',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/49992b075e62f4a99b40d25f04c998a3.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '888c25d87bc35001733ee537f33424d6',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/810c936a70753a624158463f9e58ac44.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28fa1a1ff5627ce11bce52e6afc7695e',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/5fa64c7e271328cbd251cadba7a87bf4.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32c0701eb5b223692d57286b83e72e0c',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/a0e3b13c06b4cf47e2105ce9660875bc.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9113a091ba1a222caa2914e09c51fa9',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/4d11e8bb2e5a0b27741f83b359a415b5.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '744d4071d6d243f29c4f14215b3dbd3d',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/5de617284cf5cb69dc9938ce7959d240.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6252de12eb1cbe8c597d9a70f4c96a2',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/841dc1567bf8bc4e6802f0ada1b1fb05.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b5b45c07ba951874f10faa907d9e497',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/2240efdd874e0c01e52da3434d9a8f88.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '535a69033014484e4648580ebff357e3',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/08b6e2758a15f369b41702769f54659a.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1ae0f6aa61a4229e871ac89c4636494',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/46a353c1c9970f4da08fa2a5c91b1d6e.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bbe294cd60b1174b4cb34bd0f4088acf',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/8c62753f79323333562dbf08280f203e.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4765b7db6132f5e27ffb8ddd616ba06',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/1832e7fb400c0653194acdf3c769d4d8.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '00cff99e1623bd22520a50ce4f0fcd54',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/43d619ef87f1a64c30b83482cbffbf57.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f6c797309d506c37c7caef1572db8ffe',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/0d258e9a4185bac349f407180efcb642.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '665bf6119e0eaf046504e0382cbd3e42',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/df714ec26c922d2a949a41101424c8d7.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b875fcc63ff13851d219a17dfa1095c',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/ff4994566a352b99e3082d7d8e43aead.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '916e804b641e32cb4247e74ef070b03c',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/ccc3a12d2c7e31b8ec75b308fe73c8b3.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83b0d543bafb2402eb8c11fb3a2199df',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/e3747bb7c8024e95c9662a685e7e8a4d.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '020a0d069815845cee7ac1a19ba33f7a',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/b29fdee383cf46471b34ab1573f63eda.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6fc6627479be991c4434c08f17170ad',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/f3e4870dec7a25d448fd7804f5a44a34.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d8b939c09fac8fa1709f61c73c082b6',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/20710006fa0c6f103d56d74b2b348ad1.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17eb4ff6ecbeb6dadca08ae9d4955814',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/adc87e7b262e0bc7aae3190d3c2c1fde.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc0d9183de6db0fe8e5e100a60f37fb2',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/4ea80a0435c745d9db6c134f214a6d8d.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd80296196c9b0801ffed308aada2c591',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/9c35114ce68a87c13363cffffe8aab59.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73ea4abdbe0120df4116d902b074825e',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/f76781f5c122c712cbd465b9133fcc2f.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5af0983e4b8339f8bdf148182587d82e',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/6d9298fa0fd3f3250a8729af2c69190a.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db647e4f121920904ebdf8f922237d69',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/8a4b8cd5af75ed1cdb745ece7623185b.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0f141b1e4a1595d188b921f3e737a4c7',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/9b98e0760078d7e5823e7c1f3e62e554.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ab6c79cf2a66d244caf168823711d7e',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/03f73bc7608272166cefb382f73847be.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0dc6ce848752ee84f6c760ac1e5dad5',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/9bb701a1f9901c3339af07ba95c8b053.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17644fb2291ade2078a94028cec52bed',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/447ffd68dfb50247f79af5680b5efd42.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db95dd00f22224b6ead4ca453a0ad907',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/61702696fd655d7b5342d14ad5227ba9.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4872a998296d5f7582ebaae1f3a21987',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/ac32615f5ef2bcece032a6d3193a8184.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e28ab81711217b55378f5bffd411a362',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/9238bc7a1a550e0a54ea1938f98c0052.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ddb673d93e70487f0e450f5700fff35',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/a25a254703a9c5791409d12093e10035.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b95bcdb8562bbb2d637909a59199a17b',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/ff9a8b05c11933800b3cab4e4edbec98.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '861310f0d27ed14f24601c7ba4e55d7e',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/12d4a8a31b34001fca285dac8d93fa72.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '805199e76fb3e23ff86eba9d0a5cdc7d',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/f4f60cad640a80a2dcaeeae4ef8208b9.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3908a1b09bb6e7952153c3cc5cb14c78',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/671ac5faa26e0de6ed8ff1ff960a44c4.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd23d6d89f9ad645e9f6ea3f8c1138c17',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/b5799951dec1713471fbaca003a6b66e.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a9a72968756eed960957e770939e2dd',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/ac4fa53762abee93a70a28d7f46942db.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6a28c4c540b4543531d7f6b283af39d',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/3248a855e4cfcc64f5b1bfa7a15617b3.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb942a921d788071999e27d9105d7e13',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/f09b2ba3f02b3889125f0ad6160a9ce3.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c69296b61116a8c82f50b38ac98f9d2',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/c3f45d5df06c86e4b01f1530c492a65d.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f16d85fbc82289ea8232f3cc76e0893',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/f5412456bfa638ff5a8f8942fcae56bf.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd54254f7a744328965ac1662d025128a',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/e9cb5a2f2eb99a7e68a227ff87d183a8.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f5a515783359e2c87b70b0b0ffc5f101',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/f7dfb1777e694e42562d5a930e5af96d.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2be9c44d6c3acbee9effec4246e4d964',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/692708517bb8c570c02f671685267043.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ebd154581e614e9ed5081b9af2429ae',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/420f2af3e5211ad2ebfe8c1c12a5e4ee.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3fd375d1cec52437c63e2346ce616980',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/f957043fc4873bc1bcc412644e89c541.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b0a49f9580956c0babfc73ed6545ce7',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/328a8ba580256d6f9f0176c5d65c365a.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'feff140d059c46d008985bf22cd68f54',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/fbd5f2391bee51aaf7060d52246d975d.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '499bf30c6208842031a6d0d900655143',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/9fc8b11bf731606357ded3183091153f.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '784210cdc124b55b5351772d82acb40f',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/f07491fc7845dd5ff5794c9e40d53223.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf19659a50446346849ac93ee19243ca',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/720e4e08de7fe4ef01ff7193ea2743e7.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c8512443d0183c3d56a0ea3876e1bd4',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/9a766f48013ced640fb7a7549a67dc4b.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cab0b0dac900caf740b0481442763339',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/a7acf2490e5dccbd6d6b5d007ea62521.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e1fc2b516c7798241516b4e79612498',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/54c96eaec7d9329efcaee19282861fce.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e5b1ca9e8a7962b2eb626ee94c6432e',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/7ab82276952a633e843abd9a48efa9a3.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '868d538c5cf2e506b9ddd7aea6f8b8e2',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/417dac2476baf1b955c681c90f4706c7.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9284945f9e3b2a1b108ccfe16f8a42c',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/92b841c9ff4a4e8b476fd22339af4c35.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '616256d09415059602163c43e3d859a8',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/ec8dec37881226df6472a831483261a6.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d9c5d9c6240afce68c845c30724fdd6',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/d696e4074edf942fddda5ae83ea4468c.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '42a0d2d0311e36cfb0a0cb7e064bd88b',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/72653c1dda514f44afca03a6759fec1a.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73cb7961dde945d6ee18d927879b7496',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/6348722cec302ed6f68a19d791987034.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '380076395d21fd8b3a7c33b6a9a97739',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/a1d1508d1013ea068802503f17180b8f.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '089c7363ab900d8f0b4fff2295711d49',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/261c04af7a91893f48c81c9a5c6dc1fa.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72012a74b9fca8586d84c112f3eb2c32',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/669d03cf6b8e7cfc197b0003393e6268.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e752737c10aa863abedc14fa7e64657a',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/5c0b60094f0642099e4d1287e47ef4b6.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7dbfd4be45e8398c5dda18bc6d8f5d6',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/f56b6a289b556a0044d5640bef6c1867.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88c743ebbce10adc5d1283f1ccca0416',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/39dba7ca31a0711aa99636deebc37627.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd805e212d6461343eafe740f7f00af22',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/c08c8816db73b89e82add489b27fcab4.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25c2ab2fa0059631469a9160facd5af9',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/8757ca795777b2c0d6cc4e38a5d74639.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e2a34cee107ced4988532832e3785d9',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/89d116e59ec8cb43ef9f81993bd706e1.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebe16d1857468e79d19dc802dab57870',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/5d09c74ab717e9292c4786fb99339607.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18272a135db7f70e3f53cd54ffbd441a',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/39e20937d311c036b28712132af2697a.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d952b566bd05e0c9c5b2a4374f2fef2',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'modSystemSetting/59d7848bc1ae483286568445f394dd79.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd943d04aff0727d815c4b58de25da2f6',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/a31d4082ba3a1d490ee5e5c57a972f6f.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c31e0a6d65258a52ec54274ad4b0e9d1',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/1c320e83355c02b2ba81cd2810e1aa09.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0ddcd0e68764615b90c3ee1f7fe0af7',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/2cd93e2abf682ac14e57a60d9955bbee.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f6eb97c3d7b1e25a59b07de88f81875',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/1eb663359226a0702e1f73763a38f537.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4053d2536c7be9069d597d66ef9fe64',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/f55b85ecce4df85e5f7c28efca071129.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a60fe2a437b578c2c9d58e1fa48e9bf',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/fca9d9f085c29bceca7d8090067c2ef8.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b60c6c3036e8bcb3260a4da0bfe554a',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/39ca676f1cdfbd70cc3c879854bc0350.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1dc9e04f089a009b29146c44696bed83',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/6c02a70420e0e96943924578f6c388e9.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50b16ffbfa05b3e8228e92a0184c15e9',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/385fa4dbfd66fb31befc0f2e0c285c7f.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72e893b452dc2cba2c5386b0b3c917d0',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/4d589d81b71a4c9b0d4031cbd9d10936.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd26f4b8e03c2e43852114f0ed154b4da',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/9a53748e0faa15e246ab6a0c0e01da9d.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b010409c4f6d429070565cc12a594ce',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/0dbff557c1db2afa2df9a4006252777d.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e71f3048f3681b486c4fa13d03f9b172',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/2823d11bb11d7cff9f3d821b58fb77a7.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf4ca70446ce1453da98bd21ac2253cc',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/4e1c2915d168fbd703d5573e8dc55b88.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f797b381f0b5bd492a729ec1eb58be4f',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/c22a6c25823ba130a2ebdacd4f19f632.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fbe7754a7e5421f2ebd707471df206b',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/b7e025b4f93bfb8bec82cf27fe8b4784.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fddd33cd02c1e1fb643dc300bb340315',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/48e2b9489a1055e8e014b4a60e502d9c.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e57680c60cdcd13c2464ab51f37649a',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/e2371a302ad0929ad8bd9ae72a8d3c9a.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70a29d73d5676f14cf1dae7498d22c9e',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/0c833989a73e223efd5206ac5d818204.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4984efbc1ec7567e7c6b787daa22b3d8',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'modSystemSetting/479da7bf98c6deb1e11be34e658e8544.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d881e76249de12ea3b4b2f6e6892521',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/0add41019588d965c0857cd1a9692b91.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fe159a89adbd1313f5644277448862f',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/efc30b83a100b7a83e74d006a8dde4a3.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e8a32227a463ce9a2b973c6c7cb66ab',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/caeff21157254be5d2968ffaab1e104a.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '497609ec195962bec5ea04f0d8fb6c41',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/bc693a54dd983c9b43112bd1fcfaa4b0.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f40abd1978a8b81dddba56c43d9db17',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/4fae3d4b9a54fc9cef80dade3c09cef0.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '325f3ae838fce00186ed78d5ad2e54db',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/e50156de3a48afabdaff8d3c03cfb00d.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a1e0d862d108cbf033247f05b66fe82',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/0d0fa0132f70976c1c913e1baff8f7e7.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87805cd2bf765f6f3593c1bddaf4623b',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/f433310e555788a88333e683b92f9075.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6735a349280a1b1913e3d5b3e5c284ce',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/41a5adcaf8c35995ec7ec16e867fb75a.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72723db330c74f60ab52b0001e7a93e5',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/55725c9a9f323b354c4d12418c91fc3e.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '139d460fc3ce0f79210bedabdf2e038d',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/264470c65ded21117cc7cbf4012026a0.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1476066728ef33411e607c648a69aef3',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/76c444f83a964558069842441a4172c0.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af37cd16f707316565697d29486ee1eb',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/0d93b26ea735a0645f6576e6b94abae6.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '335a9b9cde019b1b124d5f1ad49e73d6',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/6fd19f0948facae9d5491e74d78a6014.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9fa13f116b2313a2c32ad9a66466bdef',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/3219c03136c4cba79f7bfa9bfec99abe.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf064758ccfa40046697b6a9ea0f13cc',
      'native_key' => 'default_media_source_type',
      'filename' => 'modSystemSetting/cec0514fd99e350e51507f7f1a1c7bd2.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eede33a612fd99ce11fa8291f8e76350',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/a0fd74131e5d2fe2e5af5ec6829dda37.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0cd3ce9dfc626d4c4bdb6d487b6a9d2',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/e63d2a298db1a4d45bdc22f1ffa5c102.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f52c35a99089638aa1be2e55e62a0727',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/63e1a31b60f60c63e2e97b5c2d8a4135.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fda67a0f9ef544de59154b885838aff5',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/bb9370e3404fb104ba36324bef08827f.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c6ca5513b079032319d44e526be551b',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/7ab29d5ca74cb18d176353a964866adf.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcf8698e171b55806606db1c0f1e3abd',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/6ed49a00804dc2d08fe9341c771cfe98.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7863ceb804058b644ba75c28b8e01462',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/d62ac806f607ca557d3861ff0b642b9e.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54e24b82bb115f3d317c29a1a17deab2',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/642eb49b2de9728822982a3ec90c152e.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03791ce8f03c80408a7afb0c597b4aa2',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/ccd0ee637937ea18f1338b5f5828e57f.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1f0dd69c4fff26b8a8a53f9c392eef6',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/965bbd1bb796d82b3665f127b70f50e8.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ea908d95854511e9d1cd7a23facd66f',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/5faf14fb141c299bad799160d0bbc24a.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad421103b66624dcd2cc141ef9d93d96',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/95657af77199aed11d3d6f65ae4034a8.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50992ec089f9643d18788b8e1ef92c67',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/f68e497978d8c574e7dbfbcae08be065.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82fef147fc6ee4630fc1216de9784c7f',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/385c9aa89840ef4edec5be6438c9cac3.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4665c1b2b9b4c71ed13a00a534b05d2d',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/d014718147c1223ffa68018cecb9dd90.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ace8ef1003c5b317ba89f1b61ddad8b',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/df38b918efe04c12b8da8a1988deb43b.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62391d4992b3def712fe2e85b4ffa5ce',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/350a9b24e7b95c40100a59e31bbe891d.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72ca49b51e68122fa8fa0a4b0c237a6b',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/c9f85a69fd37dd228fca0d0e0c539b87.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1833673722687a8b7b8258707a2dac3f',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/2bf656281959b5d1aa1c5a3f7818e71a.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '860f458503b1e25b7460b8dd7766a34d',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/c4a8e33ed5486b84b394a1f5311fec1f.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e69e697efed64c35941553c23b8c30b3',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/0b8a9a2228cf497fb575439254075516.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8dd715c3d91a2fc7027b109cc84b7c6',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/bec805adfd2323293a819538f4a38055.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ccf9170cd447f5ab91763eab0c4b0584',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/e1a02c071ed55b2348652cb37c62820b.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '025c7a3dbab4c67ca195b84eec639e14',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/04f9f01fd438948576b4e19a8ad82450.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6f0315f34a8048651412215660371fc',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/5fd045aa2be24bd41afa54115be6ef8f.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2671f9c2a76d8addb776141ed765a92b',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/2058b0aad696cf3df4be83d7c98891af.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b8487dfcd1c98d5534d4c82936fe224',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/e21968dad45f40ca3997b30cae8ec8ae.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '957773590bdb4a2ecb4b90fbda9b335a',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/929e9d0305ce079b0ef0e6f32abe66be.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91ed76e385a9039c091ecc0333c596b0',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/21768654f4485a7aa964d2009f5960da.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40feec10bac43a78d26a6c293c4979a9',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/9f699dab791a129552d28d56737962fe.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de728e59d082ee3e256a4fd51d6e0f2e',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/8916c249fe9161588db4610889d347a8.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c29a80a0b4290918701518716b22bb3',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/d85bf8816e319d770c04cf8238026dda.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '277efbb8ccef3b23e45b90732a6e17b7',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/6111bc1fe395d886d7508c33e52e0914.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3baac92d5897b72e17fece25f9cb0db5',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/4d1836517f49205da9aa4189f5e99257.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ffa8a6d817ef968c9d5b2bb247895e7',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/f6ac872c9d0147e794931b1ceb22e847.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bffe46d92f0e0632c73dcf8e82ee2020',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/e640c4f689b0720e48aa90d0af629000.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec195ac3c8fd4adbb12b3c35539b2d2c',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/f968037751d871ed7511672fc2b02725.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c22646f5e4b9a2fc3b287fa5d9ad56cf',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/e6ab50c13a164cea62a5f0d20b7f3cb9.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4dd92321539d80d595fe1ada2c4084c5',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/459719391452efdf4659bf146236e517.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e36532760cf2b1e4ab5ea5fbf9db64d5',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/5bc85e320f71f439f99606b58ac58558.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b501f3bf2d22e9efc3e8545866821fda',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/507aff05bd76333e1b846b8e264c77e3.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e081e3c093a42dfa30b5187ea890360e',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/7114eee5480afa96280224ea57195b63.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4e94e98a2e2d25cedad1b4bebe4fdf3',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/6f3f7ed943a9f60dd84eeed75c1251c5.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1179b38f76d37d86580d7724679c6682',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/6a12334a565edbcdf21ce5aa4bca0b33.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b011a2d4eb1071dfd762b8da344606e',
      'native_key' => 'log_deprecated',
      'filename' => 'modSystemSetting/ea59bba267a121c72506d7b218d7975f.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e3f6ea13fd04bb466060919cf230cf7',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/3f34853a25677482dff16bb69855a4c2.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0775a94253d3f609a041feeea4fe8279',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/4943428c01962cb1a6ca383d32e6dc8b.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7871cfe88e3b31be5e5feeb574d284f4',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/0175dd2b333dacdc77fd01c9a9fef9d3.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cc5d756599fc9b38bc84f68db50173c',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/61d4d89887e62975fe9c00385ff8a6b9.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c399e36668a95bb5c25019b2631a03da',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/aa67493dee68b09d54293d77cf4a6d0c.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39cbed1d9054d41b77e6d8a0307e6d39',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/3138eb8db851527bb44540854c613e99.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be6faefcd3a806c9cf11de06b8dc6266',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/1e2eac1fa9e2864751452829c56d3593.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e8e225309bc2e87328f6867a5f1763a',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/101fd813ea4b12f84d3d510fb8e2065c.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44e4814900681286ab6a523e7d432226',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/8bd19707145134b1dc54730310e13311.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16a183ca8ae771a6dc79c37ae95ec8c7',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/085fa0615136438cc82ed108e6212302.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5688722283f9a14d3cb9f1e92351e32a',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/75deea9e22c2da1b59e3fd1cff009065.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a23ba728b8948a8fbd3eb2ce358a90a',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/df22554922d92547cc7918ad04e3208c.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48edbfd41d51bb4c962e9525385d5a5f',
      'native_key' => 'mail_smtp_autotls',
      'filename' => 'modSystemSetting/221ed785d3fbfd9b4b6595cc21f124db.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52bee66f4b48b51fd9660577fc9dcce8',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/ce3f1744d003e953e299b856779cb6e0.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcc61c2d396c54e4eabd06840dad7c8d',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/3c64e4824f76a32040650895c1d31fbe.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6536e526df2654201f760b313dd1febd',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/6316e05d5c826072df9302af79e569c0.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8e91c77a5a6b0697e222ea49d44a09e',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/f4190da19f0d244fbc047ab6f60781dc.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '564818e3aeb51c9080b6b3a5df5d2daa',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/eced0a68075a2ebc58e5b9fd8eb30788.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37e1dfcb7063b1f53384dd127cd8d399',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/c0589c14993248f36b2bab3f23ee7fd2.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e82ad45547aa6083c25d63c247a41d8',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/26928f24120184d7a56e2becb8ed1f02.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2df735cabd670f117c36567dbdf4ea7b',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/ba7a499ae36dc91e6aae3238efef0834.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '353b977ec741fe3239455405bb50b9a1',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/1f53b09c23bba8996fed9900b2a60522.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7a160e3bdb2e5661d247a7c908fe9cd',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/34eb7fff06f3016b464c8c575704ffe8.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '248a437767d5521c06f5b5557e0e334b',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/998a58a8b6233e0a7c4f00b45b13e18e.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d697f16f48cce78729a46907f71726e',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/d5de70788cf898f288962cdc1ecd39c3.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2570494ecb2a0f5b46a2d9ea0f7fffeb',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/9217b82404c3961b741620567084e9ba.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73825ed89ad48f96dd73a273058b7a02',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/c0164398b452b44501a3ea82a19edcc0.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6f3b2f35751afe0142ab27ab6efd066',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/df8e78183918a7c12323321e9beb30da.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '980065a0169799664fef531388a8174a',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/e0365eb3e3bb78467a62ea8abce8841b.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '372b99c8b196e28e03901bcd8625863b',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/a7136118148dc511595b5c6f097318fe.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62bdd30233741b3cee34f14fb58e23d4',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/d389eef10ec18ec3076afb82e000f59d.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5615d894667ccf66150e61b999d0964',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/f27973388678252d8e0297ad91630623.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8b8b4955b1ecbe7fa0e796ddc74f700',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/bf95c9cc0a1b2f386292c3c1d1657117.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76455f51803a81abfc3eafdde3961e56',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/08b26ef4782426c444f1cae1a25b1fb8.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd522fb3b7ce19bb7e3faacd18d7e591',
      'native_key' => 'package_installer_at_top',
      'filename' => 'modSystemSetting/9eb543b48e9be97bbc78f0dcfa0178e6.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9366286208297b3287bd905b49ba4216',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/b598318219b02d86a0a3227cfa656079.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db78f086901759c1154f46ea4abf1ab7',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/39785c105cd9c75c5f0f8ccaf4dbca82.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91895bf09865bc318ac0726eec7995b7',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/5850945e0741eac6e66b17e8fa8dd321.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ab615b60ad91fb1884ae647f3a63c5f',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/e11f4f0ff6ed6e344379fbc0d2925cc7.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46681c24b3c9b601055c122d9b9c7295',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/ab45b96bc9d7885f01b9727eb71c024d.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0815b2f1cb985f5a59c2eaf977a5809',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/0db0f752cece73fbb792f18893076ff4.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '179ceb598e80b4079fcb691304c5053d',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/95bfc3d5362def467e17524319284818.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d7c8ee613e8b5bbd3998d6878568f94',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/165c47172c31bec04a83fa46e2409bf7.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c77eef504b4d54be639936e080eb32f4',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/6d53022562a77fc2c5e6d1075ba2087a.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae26eb8cd1a1df9f5fa1efe8901f99ec',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/6ca67dce2ccf2e0a7d1cc268c1b7651a.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b08935fc78ed5858253e47c8dcfd6b98',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/907767f0436a0c40c1a9f14d0bbc3c13.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90728c3628e540563327372d15943c43',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/138297ffa133970f8d828598566dfbf8.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac7eebaff6a61f57bba4db616b95650e',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/e06bb799f38d9204cc0840ef8689c869.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfff08c4104fc507f998286652339356',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/37a09bc33b7976703509d9d2e83f14d6.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec0c268de62143f8397c4f7813e16af7',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/b2ac2cbf6247689095de9b314b0136f1.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b727c5c2db7980cfe30b58b1ded48334',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/c81162e0b2e6e0df987a77e782d5848a.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88b2433a9e74b682f8efdb4391c3d192',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/265d4e3dbeb795da1a8016f01ffde5fa.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a1ca614f14818e182467a49cbf00888',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/947035e48e8a3bd189ea5252beadca39.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a871af5f68c5bfacb71908a9982bff7',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/cdde745ad790bc1345780c176fb371b4.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08cc14946693f75ad99f22654b871464',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/c477720e646f43ee784ecbac2dbb42fd.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff6c3162b9d6f2a7803dab2d31f4963e',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/ddcfe7bf3d035473ea01efa92921dbea.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f3b7247a2245ac2c454ddf5f6343c9f',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/35f4c312311108cf584f04b044c034e3.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '263d5f50416137eb8cb4a82b29c37575',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/ffeda9a81373fd1e3930975f5eb62755.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f18ab9031a245b772d16885bebc7a716',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/812fc53760432a86d9c7813d6e338d36.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc4ba652a3cf5adf6cc965f9c7610f1e',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/76eccc5ebda973011e4759d118e35481.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '825907dc6e04a22ceeec46dca71ed248',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/c913b14432455ddd3e43370ae509724e.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b421d3606af51454e04e1ff9f2bba4f',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/bd0d46cd76350cedafba80975949774b.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '436e40801b6b25a8f680f1ad2a865d0e',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/33ae8c8af00497d908693c3b4e951cdd.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83b5630b09b891b6ed568cd6eb0623a6',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/1c763730ff6d899018b2cc3759aa9595.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '712c35b3c759cb439c57b58c74fcf924',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/5349a0cd9a119516f965148808680238.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3092ee6c92b59ddb25a33de5f2519660',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/1d385e96110aea6727c7d03a3162af3e.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6015a6d81ccb73117eac358cf667e6ec',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/1b71581ac19f4bbd232756a3f07b0a98.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd911f92b489398e1e594fc11e53ef262',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/7d52173e1fc708c4c6aa5da799cdc7a7.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '517b1e33d6855bba2fc6abbf367077dc',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/96da480a924915f7e742d5bffcbba9f4.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd896b0bc85330fa9958b0dc81f0a1e2c',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/d07fefc99261aae4c2fe09ab9eff1164.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbb05f2d5d34675a7f4ffe56f73b411c',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/1cb1de4bde101215808652046ded0203.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e954fa915850f15fa99822785d3a293',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/909114f8984fda845b3d313ffd73df5e.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbdd475728e1eb1906d8a4c563ff8493',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/ebaf6727b4cb1662db15028c8c1dea99.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d21f917d588eb4adf3fb045e240aa53',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/61dfa6b694dd6523f013748e97e2defd.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f52b4d146181fdd690eac5830a26a32',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/c046ab86d2482dfec9de034bde7ed876.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eed0413e73e99f35440fb6a0d9919424',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/b31cb93f59cf16750ff31d140754d5d0.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16f1ac68e66297b7be1d9cdd1576947c',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/8db292be2ee756de36beb92204ce040a.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '353bef4a6583c17d813f7075e71b0dc6',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/1c917c7ba7f82a487cdbc038a0fafc3a.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be96a146341b0e1ffa42612a2253c7c0',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/10f6f4c0e03d0a8652fd0bfbf56d8c25.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd6ef162b5d9e376113b2acf8b9b734d',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/5b9233ced1c99ea42c6de99813316605.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00bbe74f8ecad5fe28768e795bd15c46',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/1f897d29839bfa662e23aa6f24a5c91e.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '766614b373a7ea5f93b8f3019c64a2b8',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/0bde0559888fbdb8ddf5d753a0e03a4c.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b36a1f8108c5ecca51ba6f9fe0143ad3',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/0ebe308e9a6fc2074347cb42fc31d0b9.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ff3f8d739276202776bea0a081748c9',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/d08abadc4bfc16dc8fce6cf36641cfb0.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa7d3efc3ea0bcfe9603a55946046bcd',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/3e78b3a51c1267a9b8d84c0947ca584c.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bdad23b06130e0dbe0efff65bbe6afd',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/8079845f610f95043e5c046d4429d4f8.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '782128e18850439bea62f5ed1dd4d882',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/02a4bfc81e3e7e19c7443ce7ea060d25.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44a38fd3700b7a8b7cfa288aacf58408',
      'native_key' => 'session_cookie_samesite',
      'filename' => 'modSystemSetting/996e3443f2472062ba82a4e73918baff.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c9bebc2ccf6c7ac243748d063b43675',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/6e814ca9dc49165d9b04fa53509188e7.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b05d0debd0826e9355bf26136272a6d',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/8cc20ad40668fb5266d2dad0e5393928.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1abc31722dd001650f83b130001a83ea',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/6c6ca30b6a313f79a9d6d61902c7f10b.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67964b3417eb6388f8d8d6f9272c7959',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/1223614ae5d2072f5ac1daef45316d9b.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c0c4a42acbd7a6bb42ddabd36e31454',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/a67a8ce969079adbee73d938c294de02.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9786235fadc447af4114a4b5fa93e324',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/810b3d184f85d41b3cf4e6ae047e820b.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28e1b989216f1dd2ec5716aa3bd26967',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/ac73b4e79e489261451ec3f285a338b3.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e4aeaeebc0915cb7707da1d3363092f',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/45de63e7783b76374f207f892ab8dadb.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70708a7f43561e56cf17ba0bd418be0e',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/47c1e512565d0f7ad8f46625c085f6fe.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71b334efe345388f3e1cb074089b25ac',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/4647b15f1db83be97fff8b5a0cecbbe1.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a69dc98c49811659b70f77a2f867032',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/324f58bdb43de995c8036cc9dc0ee23c.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cef688ba0e091520932010aa7dedea04',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/aa741f93edd287f19231ddedcd71781e.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18339656495d8166d6a9822ae90ecfef',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'modSystemSetting/358ff0fbcdae8ba8a6381ee1f2314382.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '187e7c04622f3f8bcf903bf96f157ce1',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'modSystemSetting/b9cfdfd1cb1a4747a9bb79b43a37b5ba.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e638fa79f6d9e5139caa7f9861de4f3',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'modSystemSetting/d53c545ddd0cbcf65d36875db45e1dca.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd326a1aad2f8712c50cbfd9c0a8a5dd1',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'modSystemSetting/f523d279bec411bf0ebfc8adc265ab44.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3bbe86af968206c2ebd35df2165e5232',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'modSystemSetting/a9d6942ff04f3b555e64ed2fdf44c630.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eae3af5ee41474518fac543542093906',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'modSystemSetting/19c829a2cd803e49415a0beeab4e5d30.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e99085d75044c9bddbac5777d37b245',
      'native_key' => 'static_elements_default_category',
      'filename' => 'modSystemSetting/26d334c37886765e0a191f9b50d44598.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0c0f7f04304ddd8fa9d5c5af41edb9c',
      'native_key' => 'static_elements_basepath',
      'filename' => 'modSystemSetting/eef8fb8dfa6235550c9a3fd506a5a82b.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b084c09eaa02f6ed5eaf7559193a419',
      'native_key' => 'resource_static_allow_absolute',
      'filename' => 'modSystemSetting/487369d34059807ae250950ed49a61dd.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7aaeb4a68f3add4dd99f7662e2e1c7b2',
      'native_key' => 'resource_static_path',
      'filename' => 'modSystemSetting/bb36a7053f9a7f504462a4ec839663f8.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22122367f5dc13da259f5af9d3843631',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/ac9e35be050346c3b43063fd97aed404.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6f0ab78fbeab5128bb120a9d7d81d32',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/c33ac4bdd8958fa11946ae2a5dae022e.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e46f49be403f91f5b4ec87dc80a14eb',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/9460ca79abd1ce8149e00c5dd7e520ad.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15d3ff144455ba0832f7b5187ba3d5fb',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/d68327d4e7832ec4fa8a6d31d3983a55.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10bd76228bfd1b86d9278318ba41b806',
      'native_key' => 'topmenu_subitems_max',
      'filename' => 'modSystemSetting/263cf3b4f623fb610e9165f260172b4c.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fca9e47e876ae68f7ba6a24930eb49c7',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/7b0dafdb9836b11b0073a4c6cc8b62ca.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0a4dbd1ea581e4c8cebb31f6bf4c9e3',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/af4ea0435cb8121cc8132182be3a1eac.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a8dd2c6438ccd06105c0dcc5a3601c7',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/877b166989ce51ceb7b301741aa3d5f7.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f913e72cab67017e1312c2ae683ce25',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/253628b1f94cf8aa6cd10eaa1e238c0a.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '606c32ce6e6dcc8f00b6571738f167b0',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/9af471b682b98468179f6c912193c12d.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f448f0a26a2c2e06188cb193d5fd3792',
      'native_key' => 'upload_check_exists',
      'filename' => 'modSystemSetting/3b208118a5a204f0245839d0beebcff6.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e79f36a18f4c48f2e83ef39519ad35b6',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/eb5dfbe7ee3c832216d115fdcbe37575.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67b7d5827fd856882dc8398a79530014',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/95ca1b22f8629c96368d1c0d105ddcdd.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc2c1d620028bff2b075a2ef16e4ae53',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/1522d6def6e73afa1e6b8d8d42ce5c02.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2edf10189e098781dc67539db38e68af',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/f4dc81e57e2adcc8ba3d4c6ec5e1c866.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '995f4159b260d29a5c90702e5fee86b6',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/435b40f45f3d11c861904c7aebdb6c5b.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94988bbf7d228d5e92dedeaf4752bed8',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/3b7d112b75d8f694858263045dcc1142.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05d5b2435874bfd2504103ecdb92e1db',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/2b11de58e509efb489f775f648a08e43.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70ad78a2968a6129dc652668e4125672',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/3f823cba01a95b1793c0fd728feeb613.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69c779796afd94e0fefd8e32ae2d4209',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/ee56eec0d01bb5664c58166a423a7e43.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4357570ac6127df685773219cc9f97d',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/34a055d2264b443d9c18e1ef2dbf3b4c.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d31c77039a5517387b31e58758f6e53',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/ce25969f77285c8b07c07c9bd0db8584.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12f3f10d263edcdc8f80345e78e08e0a',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/07178ac77f9c77fb90fcc0b1851b5acf.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a714795a78703d724ee4861c173a22d',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/e4246d65bf1f6aeb91d6e91dc3ec3f03.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f8046ebff2fd8883f2a5364f57ad079',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/8c99f27d39309833fc00a00aae1133e4.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'beb00002f5dc031026a09f80d6570a3f',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/57a3c8fbdb533045124e3e731dc9c824.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63facc3e249c0baab9f4a66010b285f8',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/5ad39c9118dfa14aebb1a53f2fa77351.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96553bd376db541704936c73446f6682',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/4696b2d2dc3a3b056b1e9a3898e11dd6.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '722efff9a90da29961b422bd4dd744ac',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/30e226780303bd69b1000a47a16fc4be.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e89c44e1a0900d1211be50a0cde60a6f',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/7b5e186835cd3c8b2f2d9de081099d47.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed8b766857da9c18d7f69b8e1da0aff1',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/1b2a1e19dc656e352e47cea3e3a6d6a8.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd85bef1c06fce4b7a3588ea5e2ee11e',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/4adc47d38ea208b392f7d27452d53b7a.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6fcd936014a90dcea387ac607bd9f2a7',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/1a093a269a9f5e59879912f045ceede1.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f5c08324afae4c84d3aa897a9d9238d',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/efa8c636da72d93d9daaccbe008d578a.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0643109898513347cd1ec1ed0a1a8622',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/7916958e1e7754fc0456f11970d189d6.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27edfc179fff28307574132246b688e3',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/90679f8d6aa456c948517ef149d88ced.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f72f02b68bea651bd780c304c905057',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/120811d87496b957b05a2cadea50a0a5.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e01cad8d1f9c56ea5ab03886b2e440fe',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/b61f20bc2cc82fe1390bf8e62862de35.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64e8aa70e5af72154dc6ba32c30904e7',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/96a0298dea363c71b2fb123975873b78.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc1c736ba49b789f451151ff6fb170d3',
      'native_key' => 'allow_tv_eval',
      'filename' => 'modSystemSetting/c3660a338f4e1fffb71b67ac34519cd2.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6ff532821f630d6ca9a24be58c04fce',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/1728a125ac55fd2c7e0c45dbc8a28ec4.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '979f7c9ad46ba24cf899c0741c17e701',
      'native_key' => 'error_log_filename',
      'filename' => 'modSystemSetting/d9dedd5e35eda8979f7660ebc909dcd1.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b6413bb6d022a57f5790add242c12f2',
      'native_key' => 'error_log_filepath',
      'filename' => 'modSystemSetting/9c513017361566b2c705f8d22cad3894.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c137a5bcace9c27b024463c5f7851a5',
      'native_key' => 'static_elements_html_extension',
      'filename' => 'modSystemSetting/768db959b364240a6dd5e778127c72b8.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'ee37b58db04f281f4a3ed8635aa872b4',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/3912275d621206cad351c4572630408d.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '2168ba512c55741b1842aa103ac9a35b',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/55fc5245b6589e105835d6d96708fe7c.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '50953e017aff07e4313e73c4af7a431d',
      'native_key' => 1,
      'filename' => 'modUserGroup/94ee393635a2c38faf006410fcf0f4f8.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '434f18ae343c1bd6ff978a8a95012dad',
      'native_key' => 1,
      'filename' => 'modDashboard/8fcadc4cf37db09ed12ff92157889388.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'dfa24b5e1f1bdf33a636342c384a08dd',
      'native_key' => 1,
      'filename' => 'modMediaSource/e22f8f27ee02944cd566cbe38e76a491.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '70ccabab52dbcf1c0923f60f31be76a4',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/c7af7206f5196527ca27a0c0076ccb5a.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '73fa02953f69eaddbfdd6e84a1cfa7c6',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/1a5c9634c052b43fbcb8d59a36efb10e.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '1e2e5df4bd58cdaca650f87f21b5ce15',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/5df05432a08963549431a0e242a22ec8.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'dcecff4203e36b0640b4d0e9df366f83',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/d0e657efddbc6f8caae335fb714a2f03.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'a22e5e56e5419aba1e4537744cf300d9',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/d2962a060118cdaedac4b84259120295.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '2f9aa86c83e860a0a5cdb30e174700a0',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/37cc04fe5cbaba507ec49e6d9d1edea5.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '6b48f0450f050d4584ec42fe1fd53c2a',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/309434cc9de2026fe07770e8e099b5f8.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '6e89a1dba81d447eceb785b229771dc2',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/c7ee155dff3dfe95c088cb88ea7f437a.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '3cc39ffd79523c84122d0e389f067ded',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/ad57a9db5f37d39b51bd29086e2fe2d0.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'c4ff28fd553dc7c5cc42c48697e82a73',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/a80c07ffd5232cfba3fcc1e8669daa60.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '94edde3b05aeaa3793ae6f9d0747c31f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/a46b398f6a5248b35a5b91b0c5c581ac.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'f56207dee496a3f14a938d6269421991',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/1861c4f6695abaa45af0c0d592ee3a09.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '7bad2ca51f906a881f971cff460eb487',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/1a23ec14052c3135a19e46d802d43133.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '69d8c6f168bd789c4f50a75de68f8f0f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/4d84d88a2cce26a07025141cc2b06756.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '3099ac633740403450e484bec1d8b448',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/1f11478b99f50178eaf9acce6e74f236.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '48e2755857e09ab2bdb4efea5a95d736',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/fffe55e877cba42d0cdf031720e37f70.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '4adf2ece3d962b4f457d25477443cd71',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/439460f876165cefdcbc36d238082e41.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '3cc03bf2cfd4ae24dd2f7c71323e5a34',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/415ba3ccfb332f5797714c4ddc4a6f0f.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'ada853866891ada9b067aa108ecd43bb',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b02acb2c86e7ca1d1bde28dfe2be9fe3.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '365a4625676ea117f0ac39625529bf83',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/e8b6da484e30845cffe218fd5492de99.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd1b2c0def375a6f53d9adc59de3d9793',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/4997f1c2cac707605e65743c4704c503.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'bdf4d52f1b2da00e3828c76b6aed7e02',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/742143a01469a52d93f915c3f3a7cfd6.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e31b1f8444dc04b5b1c75c60b5370264',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/0d6773eb38b8b99d121525f0a49be746.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '79b167ac04a415fc7c6f7924d3806dea',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/f4a41f7817419e7373d45c7eabfca205.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '717c11f5c04265b9d8fdded2fdb404da',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/6c33f74c3550721d1bd668b6bd63cc4c.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a9812636a4b93fb01411ebbdfb4ebbe3',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/6331a8729f857d88d9d2d2b322eb9fbe.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'dd7c09104b25124622becbf753661db8',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/96ccf71f377adecce839d97109ab32d1.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3f1666e328c5d7b46f12cbe85f50764f',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/87fdd67eb33270f6a402b9b57c34e3da.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '280b2a07c8ebc8086a1fe219d07f2e4a',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/7f1f66040acb00b9b5f498499341c12e.vehicle',
    ),
    494 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '11618802e0958e73aa0b56a94c6efd60',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/b3832a603c56538ccd7dced7828ae8dd.vehicle',
    ),
    495 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd79c9295de45407fecb66b90898aa5e8',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/a98392a7c847e43a7f7045b7bcf8b73b.vehicle',
    ),
    496 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0f17194ff9a74c508888a63802899386',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/e394bd563d53639b8dec34428c19ac7b.vehicle',
    ),
    497 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'f3cffb0f94725b783551eb0bf4e0ab79',
      'native_key' => 'web',
      'filename' => 'modContext/0c7a3f6bd8724f65d11372890062b488.vehicle',
    ),
    498 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '55203a3d33397e885e1c73b0abf94be7',
      'native_key' => 'mgr',
      'filename' => 'modContext/03bb3aac4e370ff164f8dd8ac535a3a4.vehicle',
    ),
    499 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '76fea78561ef5662be9095e68260e441',
      'native_key' => '76fea78561ef5662be9095e68260e441',
      'filename' => 'xPDOFileVehicle/2ae8759b59547db3b898db54fa8e2657.vehicle',
    ),
    500 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '749033f31f58e67cbc30d08ab871db16',
      'native_key' => '749033f31f58e67cbc30d08ab871db16',
      'filename' => 'xPDOFileVehicle/2ac7b5444e8e7f574fb5b1944a0e08ee.vehicle',
    ),
    501 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '736f4e473faf9ecda08058597dd80940',
      'native_key' => '736f4e473faf9ecda08058597dd80940',
      'filename' => 'xPDOFileVehicle/38cacf63cf4d69d5c66dd17992ffe0ac.vehicle',
    ),
    502 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '74f6906f614c61c93111d8109003c6f8',
      'native_key' => '74f6906f614c61c93111d8109003c6f8',
      'filename' => 'xPDOFileVehicle/48eae01e97704cdc5d716031d94f6967.vehicle',
    ),
  ),
);