--------------------
Snippet: FormIt
--------------------
Author: Sterc <modx@sterc.nl>

A form processing Snippet for MODx Revolution.

Official Documentation:
https://docs.modx.com/extras/revo/formit