
backupmodx


Author: Quadro - Jan Dähne info@quadro-system.de
Copyright 2015

Official Documentation: http://www.quadro-system.de/modx-extras/backupmodx.html

Bugs and Feature Requests: https://github.com:jdaehne/BackupMODX

Questions: http://forums.modx.com

Created by MyComponent
