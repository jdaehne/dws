<?php
class qsbSet extends xPDOSimpleObject {}