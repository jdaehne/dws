FileSluggy
--------------------
Version: 1.3.4
Author: Sterc <modx@sterc.nl>
--------------------

A MODx Revolution plugin to convert a filename to lowercase and removes strange and unwanted characters. Also has the option to sanitize directory names when creating or renaming directories.
Uses the OnFileManagerUpload, OnFileManagerDirCreate and OnFileManagerDirRename events. 

Suggestions and Bugs can be submitted on Github: https://github.com/sterc/filesluggy/issues
