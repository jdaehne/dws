<?php
/**
 * The default lexicon topics for the LexiconEditor
 *
 * @package lexiconeditor
 * @subpackage lexicon
 */

$_lang['lexiconeditor'] = 'Lexicon-Editor';
$_lang['lexiconeditor.tab'] = 'Lexicon';

$_lang['lexiconeditor.menu'] = 'Lexicon-Editor';
$_lang['lexiconeditor.menu_desc'] = 'Edit your Lexicon.';

$_lang['lexiconeditor.management_desc'] = 'Edit your Lexicon.';
