<?php
/**
 * The default lexicon topics for the LexiconEditor
 *
 * @package lexiconeditor
 * @subpackage lexicon
 */

$_lang['lexiconeditor'] = 'Lexikon-Editor';
$_lang['lexiconeditor.tab'] = 'Lexikon';

$_lang['lexiconeditor.menu'] = 'Lexikon-Editor';
$_lang['lexiconeditor.menu_desc'] = 'Bearbeiten Sie Ihr Lexikon.';

$_lang['lexiconeditor.management_desc'] = 'Bearbeiten Sie Ihr Lexikon.';
