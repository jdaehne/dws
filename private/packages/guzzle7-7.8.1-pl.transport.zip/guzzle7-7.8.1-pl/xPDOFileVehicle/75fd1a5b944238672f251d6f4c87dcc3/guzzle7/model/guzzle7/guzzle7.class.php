<?php

require_once dirname(__DIR__, 2) . '/bootstrap.php';

class Guzzle7
{

}
