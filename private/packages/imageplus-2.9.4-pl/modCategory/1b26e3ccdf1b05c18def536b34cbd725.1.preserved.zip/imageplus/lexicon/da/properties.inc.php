<?php

/** Snippet properties */
$_lang['imageplus.imageplus.docid'] = 'Ressource hvorfra Image+ TV værdien bliver modtaget.';
$_lang['imageplus.imageplus.options'] = 'Udvidede phpThumbindstillinger for billedet.';
$_lang['imageplus.imageplus.tpl'] = 'Skabelonchunk som snippet skal anvende.';
$_lang['imageplus.imageplus.tvname'] = 'Navnet på Image+ TV.';
$_lang['imageplus.imageplus.type'] = 'Outputtype fra snippet. Kan sættes til <i>check</i> <i>tpl</i> eller <i>thumb</i>.';
