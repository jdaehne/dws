<?php
$_lang['sitedashclient'] = 'SiteDash Client';
