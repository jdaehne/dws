<?php
require_once (dirname(dirname(__FILE__)) . '/redconfigurationset.class.php');
class redConfigurationSet_mysql extends redConfigurationSet {}