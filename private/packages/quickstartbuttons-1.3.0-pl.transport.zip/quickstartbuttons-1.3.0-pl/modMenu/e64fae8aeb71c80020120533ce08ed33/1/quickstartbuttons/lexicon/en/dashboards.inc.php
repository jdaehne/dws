<?php

$_lang['quickstartbuttons.widget'] = "Quickstart Buttons";
$_lang['quickstartbuttons.widget_desc'] = "The Quickstart Buttons widget";
