<?php

$_lang['quickstartbuttons.widget'] = "Quickstart-Buttons";
$_lang['quickstartbuttons.widget_desc'] = "Das Quickstart-Buttons-Widget";
