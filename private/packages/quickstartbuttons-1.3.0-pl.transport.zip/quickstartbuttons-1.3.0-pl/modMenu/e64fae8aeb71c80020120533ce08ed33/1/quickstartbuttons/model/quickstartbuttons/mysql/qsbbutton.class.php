<?php
require_once (dirname(dirname(__FILE__)) . '/qsbbutton.class.php');
class qsbButton_mysql extends qsbButton {}