
backupmodx

Author: Jan Dähne <https://www.quadro-system.de>
Copyright 2018

Official Documentation: https://www.quadro-system.de/modx-extras/backup-modx/

Bugs and Feature Requests: https://github.com:jdaehne/BackupMODX

Questions: http://forums.modx.com

Created by MyComponent
